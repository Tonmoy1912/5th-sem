arr=[0,0,0,0]
print(arr)